from endstone_tpa_plugin.tpa_plugin import TpaPlugin

__all__ = ["TpaPlugin"]